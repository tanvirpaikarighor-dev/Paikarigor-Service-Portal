# পাইকারিঘর

Source: https://sites.google.com/view/paikarighorfaq/home

---

## Hair

[সিক্রেট হেয়ার প্যাক](https://sites.google.com/view/paikarighorfaq/home/%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%B9%E0%A6%AF%E0%A6%B0-%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

[PKG রাইস ওয়াটার উইথ হার্বস শ্যাম্পু](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B0%E0%A6%87%E0%A6%B8-%E0%A6%93%E0%A6%AF%E0%A6%9F%E0%A6%B0-%E0%A6%89%E0%A6%87%E0%A6%A5-%E0%A6%B9%E0%A6%B0%E0%A6%AC%E0%A6%B8-%E0%A6%B6%E0%A6%AF%E0%A6%AE%E0%A6%AA?authuser=0)

[PKG সিক্রেট হেয়ার অয়েল](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%B9%E0%A6%AF%E0%A6%B0-%E0%A6%85%E0%A6%AF%E0%A6%B2?authuser=0)

[সিক্রেট ড্যানড্রাফ প্যাক](https://sites.google.com/view/paikarighorfaq/home/%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%A1%E0%A6%AF%E0%A6%A8%E0%A6%A1%E0%A6%B0%E0%A6%AB-%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

## Face

[PKG সিক্রেট ফেসপ্যাক](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%AB%E0%A6%B8%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

[PKG সিক্রেট একনিপ্যাক](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%8F%E0%A6%95%E0%A6%A8%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

[PKG সিক্রেট পৌর মিনিমাইজার প্যাক](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%AA%E0%A6%B0-%E0%A6%AE%E0%A6%A8%E0%A6%AE%E0%A6%87%E0%A6%9C%E0%A6%B0-%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

[PKG সিক্রেট নাইট ক্রিম](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%A8%E0%A6%87%E0%A6%9F-%E0%A6%95%E0%A6%B0%E0%A6%AE?authuser=0)

[PKG মেলাজমা রিমুভার প্যাক](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%AE%E0%A6%B2%E0%A6%9C%E0%A6%AE-%E0%A6%B0%E0%A6%AE%E0%A6%AD%E0%A6%B0-%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

[মেলাসমা ক্রিম](https://sites.google.com/view/paikarighorfaq/home/%E0%A6%AE%E0%A6%B2%E0%A6%B8%E0%A6%AE-%E0%A6%95%E0%A6%B0%E0%A6%AE)

[PKG একনি জেল ক্রিম](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%8F%E0%A6%95%E0%A6%A8-%E0%A6%9C%E0%A6%B2-%E0%A6%95%E0%A6%B0%E0%A6%AE)

## Body

[PKG হোয়াইটেনিং বডি লোশন](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B9%E0%A6%AF%E0%A6%87%E0%A6%9F%E0%A6%A8-%E0%A6%AC%E0%A6%A1-%E0%A6%B2%E0%A6%B6%E0%A6%A8?authuser=0)

[সিক্রেট বডিপ্যাক](https://sites.google.com/view/paikarighorfaq/home/%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%AC%E0%A6%A1%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

## Lip & Maju

[PKG সিক্রেট লিপবাম](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%B2%E0%A6%AA%E0%A6%AC%E0%A6%AE?authuser=0)

[PKG মাজুফল প্যাক](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%AE%E0%A6%9C%E0%A6%AB%E0%A6%B2-%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

## Hair FAQ

[Hairpack FAQ](https://sites.google.com/view/paikarighorfaq/home/hairpack-faq)

## Face FAQ

[Melasma Pack FAQ](https://sites.google.com/view/paikarighorfaq/home/melasma-remover-pack-faq)

## Body FAQ

[PKG হোয়াইটেনিং বডি লোশন](https://sites.google.com/view/paikarighorfaq/home/pkg-%E0%A6%B9%E0%A6%AF%E0%A6%87%E0%A6%9F%E0%A6%A8-%E0%A6%AC%E0%A6%A1-%E0%A6%B2%E0%A6%B6%E0%A6%A8?authuser=0)

[সিক্রেট বডিপ্যাক](https://sites.google.com/view/paikarighorfaq/home/%E0%A6%B8%E0%A6%95%E0%A6%B0%E0%A6%9F-%E0%A6%AC%E0%A6%A1%E0%A6%AA%E0%A6%AF%E0%A6%95?authuser=0)

## Lip & Maju FAQ

[Lip Balm FAQ](https://sites.google.com/view/paikarighorfaq/home/lip-bum-faq)

[Up-Sell SOP Script](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fup-sell-call-sop%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw2tlXKZFAdlhqFbZhXj5-Vq)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fup-sell-call-sop%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw2tlXKZFAdlhqFbZhXj5-Vq)

[Non-Voice SOP](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fnon-voice-sop%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw0_EoZhAu0p8EWIrH0qP1xB)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fup-sell-call-sop%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw2tlXKZFAdlhqFbZhXj5-Vq)

[PKG Product Details](https://docs.google.com/document/d/1Hn7RfxXzMmfaclP4eX_9bGe6D1NZ8klQ39Gn6oAnteI/edit?tab=t.q5p2ngmxafy)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://docs.google.com/document/d/1Hn7RfxXzMmfaclP4eX_9bGe6D1NZ8klQ39Gn6oAnteI/edit?tab=t.q5p2ngmxafy)

[Up-Sell Hold & Cancel Guideline's](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Forder-on-hold-reason-guidelines-for-up-sell-team&sa=D&sntz=1&usg=AOvVaw3lbtUnGE2EVB0-jhcjUlv5)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Forder-on-hold-reason-guidelines-for-up-sell-team&sa=D&sntz=1&usg=AOvVaw3lbtUnGE2EVB0-jhcjUlv5)

[All Portal Link and Tools](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fall-portal-link%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw109sm0rwVQ4wwj7klXKPim)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fall-portal-link%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw109sm0rwVQ4wwj7klXKPim)

[Paikarighor Product Picture](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fpaikarighor-product-picture%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw37tz0vFtXIH--EEtm5B2KD)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fpaikarighor-product-picture%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw37tz0vFtXIH--EEtm5B2KD)

[Objection Handling Top Queries \| UP-Sell](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fvoice-faq%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw3DucLqwQ8Sny5KvvlVXSzF)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fvoice-faq%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw3DucLqwQ8Sny5KvvlVXSzF)

[Return Parcel Adjustment Guideline](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Freturn-parcel-adjustment-guideline&sa=D&sntz=1&usg=AOvVaw1JjzuK8RjleGkH_0MqbMZX)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Freturn-parcel-adjustment-guideline&sa=D&sntz=1&usg=AOvVaw1JjzuK8RjleGkH_0MqbMZX)

[Non-Voice Order Cancel Guideline](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fnon-voice-order-cancel-guideline&sa=D&sntz=1&usg=AOvVaw2z4yaZi1UuX5R7n3Mgt8QY)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fnon-voice-order-cancel-guideline&sa=D&sntz=1&usg=AOvVaw2z4yaZi1UuX5R7n3Mgt8QY)

[Non-Voice Order Cancel Guideline](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fnon-voice-order-cancel-guideline&sa=D&sntz=1&usg=AOvVaw2z4yaZi1UuX5R7n3Mgt8QY)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fnon-voice-order-cancel-guideline&sa=D&sntz=1&usg=AOvVaw2z4yaZi1UuX5R7n3Mgt8QY)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://docs.google.com/document/d/1I1Jzj1Zpvu9XoDGlKMU6vK4qmbmNM9MRtfvbrdGnaoE/edit?tab=t.0)

[Paikarighor Delivery Charge](https://docs.google.com/document/d/1I1Jzj1Zpvu9XoDGlKMU6vK4qmbmNM9MRtfvbrdGnaoE/edit?tab=t.0)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fpaikarighor.com%2F&sa=D&sntz=1&usg=AOvVaw3ZloAjL5nuvi16u2ow_BoJ)

[Our Official Website Link](https://www.google.com/url?q=https%3A%2F%2Fpaikarighor.com%2F&sa=D&sntz=1&usg=AOvVaw3ZloAjL5nuvi16u2ow_BoJ)

[Special Offer Campaign](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fspecial-offer-campaign%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw1bYGk0ApwlayDXQzvGTq9z)

[![Link](https://ssl.gstatic.com/atari/images/sociallinks/link_white_28dp.png)](https://www.google.com/url?q=https%3A%2F%2Fsites.google.com%2Fview%2Fpaikarighorfaq%2Fhome%2Fspecial-offer-campaign%3Fauthuser%3D0&sa=D&sntz=1&usg=AOvVaw1bYGk0ApwlayDXQzvGTq9z)

# Bkash/ Nagad Payment Number: 01722866438

## Rocket Payment Number: 017228664383

## Outbound Helpline Number: 09643214945

## Inbound Hotline Number: 09643200900
