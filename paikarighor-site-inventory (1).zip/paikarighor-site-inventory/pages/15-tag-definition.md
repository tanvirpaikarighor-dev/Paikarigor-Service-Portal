# Tag Definition

Source: https://sites.google.com/view/paikarighorfaq/home/tag-definition

---

# Tag Definition

Category

Tag Name

Definition

Problem

Hair problem C

কাস্টমার যখন হেয়ার প্যাক বা সিক্রেট হেয়ার অয়েল ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Melasma Problem C

কাস্টমার যখন মেলাসমা ক্রিম বা PKG মেলাজমা রিমুভার প্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Lip problem C

কাস্টমার যখন PKG সিক্রেট লিপবাম ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Majufol related C

কাস্টমার যখন PKG মাজুফল প্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Face problem C

কাস্টমার যখন PKG সিক্রেট ফেসপ্যাক, PKG সিক্রেট নাইট ক্রিম ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Body problem C

কাস্টমার যখন PKG হোয়াইটেনিং বডি লোশন, সিক্রেট বডিপ্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Acne problem C

কাস্টমার যখন PKG সিক্রেট একনিপ্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Pore problem C

কাস্টমার যখন PKG সিক্রেট পৌর মিনিমাইজার প্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Problem

Dandruff problem C

কাস্টমার যখন PKG রাইস ওয়াটার উইথ হার্বস শ্যাম্পু, সিক্রেট ড্যানড্রাফ প্যাক ব্যবহারের পরে কোনো প্রব্লেম শেয়ার করে।

Delivery

Delivery time R

কাস্টমার যখন ডেলিভারি টাইম পরিবর্তন রিকোয়েস্ট করে।

Delivery

Delivery time Q

কাস্টমার যখন ডেলিভারি টাইম সম্পর্কে জানতে চায়।

Delivery

Delay Delivery C

কাস্টমারের ডেলিভারি timeline ওভার হওয়ায় আমাদের কাছে কোয়েরি করলে।

Delivery

Delivery Charge C

কাস্টমার যখন ডেলিভারি চার্জ নিয়ে কমপ্লেইন করে।

Delivery

Delivery Charge Q

কাস্টমার যখন ডেলিভারি চার্জ নিয়ে জানতে চায়।

Ingredients

Ingredients R

Ingredients

Ingredients C

Ingredients

Ingredients Q

কাস্টমার যখন প্রোডাক্টের উপাদান সম্পর্কে জানতে চায়।

Price Negotiations

Price Negotiations Q

কাস্টমার যখন প্রোডাক্ট এর প্রাইস নিয়ে দামাদামি করে।

Product Weight

Product Weight R

কাস্টমার যখন প্রোডাক্টের ওজন বাড়ানোর রিকোয়েস্ট করে।

Product Weight

Product Weight C

কাস্টমার যখন প্রোডাক্টের ওজন নিয়ে কোনো কমপ্লেইন করে।

Product Weight

Product Weight Q

কাস্টমার যখন প্রোডাক্ট এর ওজন সম্পর্কে জানতে চায়।

Product Review

Product Review Q

কাস্টমার যখন প্রোডাক্টের রিভিউ সম্পর্কে জানতে চায়।

Payment

Payment C

কাস্টমার যখন পেমেন্টজনিত সমস্যা নিয়ে কমপ্লেইন করে।

Payment

Nagad number Q

কাস্টমার যখন নগদ একাউন্ট থেকে পেমেন্ট করার প্রসেস জানতে চায়।

Payment

Bkash number Q

কাস্টমার যখন বিকাশ একাউন্ট থেকে পেমেন্ট করার প্রসেস জানতে চায়।

Payment

Payment procedure Q

কাস্টমার কিভাবে পেমেন্ট করবে এই বিষয় সম্পর্কে জানতে চায়।

Showroom address

Showroom address Q

কাস্টমার যখন Showroom এর ঠিকানা জানতে চায়।

Review

Negative review

কাস্টমার যখন কোনো প্রোডাক্ট এর নেগেটিভ রিভিউ দেয়।

Review

positive review

কাস্টমার যখন কোনো প্রোডাক্ট এর positive রিভিউ দেয়।

Helpline

Helpline related Q

কাস্টমার যখন হেল্পলাইন নম্বর সম্পর্কে জানতে চায়।

Others

Others Q

Junk

Junk

কাস্টমার যখন আমাদের প্রোডাক্ট এর বাইরে কোনো অসামঞ্জস্য কথা বলে।

Spam

spam

কাস্টমার যখন গালি অথবা adult কোনো কথা বলে। (Spam করলে কাস্টমার পুনরায় আমাদেরকে knock দিতে পারে না)

Majufol

Majufol Order

কাস্টমার যখন মাজুফল অর্ডার করতে চায়।

Majufol

Majufol R

Majufol

Majufol C

কাস্টমার যখন মাজুফলের কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Majufol

Majufol Q

কাস্টমার যখন মাজুফল সম্পর্কে জানতে চায়।

Night Cream

Night Cream Order

কাস্টমার যখন নাইট ক্রিম অর্ডার confirm করবে।

Night Cream

Night Cream R

কাস্টমার যখন প্রোডাক্ট নিতে চাইবে।

Night Cream

Night Cream C

কাস্টমার যখন নাইট ক্রিম এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Night Cream

Night Cream Q

কাস্টমার যখন নাইট ক্রিম সম্পর্কে জানতে চায়।

Melasma Remover Cream

Melasma Remover Cream Order

কাস্টমার যখন মেলাজমা রিমুভার ক্রিম অর্ডার করতে চায়।

Melasma Remover Cream

Melasma Remover Cream R

Melasma Remover Cream

Melasma Remover Cream C

কাস্টমার যখন মেলাজমা রিমুভার ক্রিম এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Melasma Remover Cream

Melasma Remover Cream Q

কাস্টমার যখন মেলাজমা রিমুভার ক্রিম সম্পর্কে জানতে চায়।

Melasma Remover Pack

Melasma Remover Pack Order

কাস্টমার যখন মেলাজমা রিমুভার প্যাক অর্ডার করতে চায়।

Melasma Remover Pack

Melasma Remover Pack R

Melasma Remover Pack

Melasma Remover Pack C

কাস্টমার যখন মেলাজমা রিমুভার প্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Melasma Remover Pack

Melasma Remover Pack Q

কাস্টমার যখন মেলাজমা রিমুভার প্যাক সম্পর্কে জানতে চায়।

PKG secret lip bum

PKG secret lip bum Order

কাস্টমার যখন সিক্রেট লিপবাম অর্ডার করতে চায়।

PKG secret lip bum

PKG secret lip bum R

PKG secret lip bum

PKG secret lip bum C

কাস্টমার যখন সিক্রেট লিপবাম এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

PKG secret lip bum

PKG secret lip bum Q

কাস্টমার যখন সিক্রেট লিপবাম সম্পর্কে জানতে চায়।

PKG secret body lotion

PKG secret body lotion Order

কাস্টমার যখন সিক্রেট বডি লোশন অর্ডার করতে চায়।

PKG secret body lotion

PKG secret body lotion R

PKG secret body lotion

PKG secret body lotion C

কাস্টমার যখন সিক্রেট বডি লোশন এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

PKG secret body lotion

PKG secret body lotion Q

কাস্টমার যখন সিক্রেট বডি লোশন সম্পর্কে জানতে চায়।

Secret bodypack

Secret bodypack Order

কাস্টমার যখন সিক্রেট বডি প্যাক অর্ডার করতে চায়।

Secret bodypack

Secret bodypack R

Secret bodypack

Secret bodypack C

কাস্টমার যখন সিক্রেট বডি প্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret bodypack

Secret bodypack Q

কাস্টমার যখন সিক্রেট বডি প্যাক সম্পর্কে জানতে চায়।

secret pore minimizer pack

secret pore minimizer pack Order

কাস্টমার যখন সিক্রেট পৌর মিনিমাইজার প্যাক অর্ডার করতে চায়।

secret pore minimizer pack

secret pore minimizer pack R

secret pore minimizer pack

secret pore minimizer pack C

কাস্টমার যখন সিক্রেট পৌর মিনিমাইজার প্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

secret pore minimizer pack

secret pore minimizer pack Q

কাস্টমার যখন সিক্রেট পৌর মিনিমাইজার প্যাক সম্পর্কে জানতে চায়।

Secret acnepack

Secret acnepack Order

কাস্টমার যখন সিক্রেট একনিপ্যাক প্যাক অর্ডার করতে চায়।

Secret acnepack

Secret acnepack R

Secret acnepack

Secret acnepack C

কাস্টমার যখন সিক্রেট একনিপ্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret acnepack

Secret acnepack Q

কাস্টমার যখন সিক্রেট একনিপ্যাক সম্পর্কে জানতে চায়।

Secret facepack

Secret facepack Order

কাস্টমার যখন সিক্রেট ফেসপ্যাক প্যাক অর্ডার করতে চায়।

Secret facepack

Secret facepack R

Secret facepack

Secret facepack C

কাস্টমার যখন সিক্রেট ফেসপ্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret facepack

Secret facepack Q

কাস্টমার যখন সিক্রেট ফেসপ্যাক সম্পর্কে জানতে চায়।

PKG rice water with herbs shampoo

PKG rice water with herbs shampoo Order

কাস্টমার যখন রাইস ওয়াটার উইথ হার্বস শ্যাম্পু অর্ডার করতে চায়।

PKG rice water with herbs shampoo

PKG rice water with herbs shampoo R

PKG rice water with herbs shampoo

PKG rice water with herbs shampoo C

কাস্টমার যখন রাইস ওয়াটার উইথ হার্বস শ্যাম্পু এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

PKG rice water with herbs shampoo

PKG rice water with herbs shampoo Q

কাস্টমার যখন রাইস ওয়াটার উইথ হার্বস শ্যাম্পু সম্পর্কে জানতে চায়।

Secret Dandruff pack

Secret Dandruff pack Order

কাস্টমার যখন সিক্রেট ড্যানড্রাফ প্যাক অর্ডার করতে চায়।

Secret Dandruff pack

Secret Dandruff pack R

Secret Dandruff pack

Secret Dandruff pack C

কাস্টমার যখন সিক্রেট ড্যানড্রাফ প্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret Dandruff pack

Secret Dandruff pack Q

কাস্টমার যখন সিক্রেট ড্যানড্রাফ প্যাক সম্পর্কে জানতে চায়।

Secret Hairoil

Secret Hairoil Order

কাস্টমার যখন সিক্রেট হেয়ার অয়েল অর্ডার করতে চায়।

Secret Hairoil

Secret Hairoil R

Secret Hairoil

Secret Hairoil C

কাস্টমার যখন সিক্রেট হেয়ার অয়েল এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret Hairoil

Secret Hairoil Q

কাস্টমার যখন সিক্রেট হেয়ার অয়েল সম্পর্কে জানতে চায়।

Secret hairpack

Secret hairpack Order

কাস্টমার যখন সিক্রেট হেয়ার প্যাক অর্ডার করতে চায়।

Secret hairpack

Secret hairpack R

Secret hairpack

Secret hairpack C

কাস্টমার যখন সিক্রেট হেয়ার প্যাক এর কার্যকারিতা সম্পর্কে কমপ্লেইন করে।

Secret hairpack

Secret hairpack Q

কাস্টমার যখন সিক্রেট হেয়ার প্যাক সম্পর্কে জানতে চায়।
