# Special Offer Campaign

Source: https://sites.google.com/view/paikarighorfaq/home/special-offer-campaign

---

Special Offer Campaign

বিশেষ কম্বো অফার

Face Pack + Night Cream

মূল্য: ১,৩৩০ টাকা

সুবিধা: ফ্রি ডেলিভারি

Melasma Remover Pack + PKG Melasma Cream

মূল্য: ১,৫০০ টাকা

সুবিধা: ফ্রি ডেলিভারি অথবা ফ্রি লিপ বাম

সিক্রেট একনি প্যাক \+ Acne Gel Cream

রেগুলার মূল্য: ১,৩৪০ টাকা

বিশেষ মূল্য: ১,২৭০ টাকা

সিক্রেট হেয়ার প্যাক \+ সিক্রেট হেয়ার অয়েল (২০০ মি.লি.)

রেগুলার মূল্য: ১,৯৮০ টাকা

বিশেষ মূল্য: ১,৮৯০ টাকা
