# Non-Voice Order Cancel Guideline

Source: https://sites.google.com/view/paikarighorfaq/home/non-voice-order-cancel-guideline

---

Non-Voice Order Cancel Guideline

কাস্টমার: আমি আমার অর্ডারটি ক্যানসেল করতে চাই।

কাস্টমার: এখন আর পণ্যটি প্রয়োজন নেই/ নিতে চাই না/হাসবেন্ড না করেছে।

এজেন্ট:  আমরা আপনার বিষয়টি আমাদের কনসার্ন টিমকে শেয়ার করে দিচ্ছি, বিষয়টি নিয়ে আমাদের একজন প্রতিনিধি খুব দ্রুত আপনার সাথে যোগাযোগ করবে।

কাস্টমার: ঠিক আছে, ধন্যবাদ।

এজেন্ট: মোস্ট ওয়েলকাম।
