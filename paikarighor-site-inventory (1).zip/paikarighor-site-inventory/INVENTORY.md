# পাইকারিঘর (Paikarighor FAQ) — Site Inventory

Original site: https://sites.google.com/view/paikarighorfaq/home
Inspected: 10 Nov 2026
Site title shown in header: **পাইকারিঘর** (with logo, `images/site-logo.png`)

## 1. What was collected

| Item | Count | Where it is saved |
|---|---|---|
| Pages (homepage + subpages) | 32 (1 + 31) | `pages/*.md` (original text, word for word) |
| Content per section/column (for faithful rebuild) | 32 pages | `site-content.json` |
| Original page source (backup) | 32 | `raw-html/` |
| Images | 19 (1 logo + 18 content images) | `images/` |
| Public linked Google Docs (text copy) | 3 | `linked-documents/` |
| External links | 15 unique | Section 6 below |

Every page in the menu opened successfully. No page on the Google Site itself was blocked.

## 2. Site structure (navigation menu)

The site has one top menu item, **Home**, with 31 pages under it (one level deep, no deeper levels). Order below is the original menu order.

```text
Home
├─ সিক্রেট হেয়ার প্যাক
├─ PKG রাইস ওয়াটার উইথ হার্বস শ্যাম্পু
├─ PKG সিক্রেট হেয়ার অয়েল
├─ সিক্রেট ড্যানড্রাফ প্যাক
├─ PKG সিক্রেট ফেসপ্যাক
├─ PKG সিক্রেট একনিপ্যাক
├─ PKG সিক্রেট পৌর মিনিমাইজার প্যাক
├─ PKG সিক্রেট নাইট ক্রিম
├─ PKG মেলাজমা রিমুভার প্যাক
├─ মেলাসমা ক্রিম
├─ PKG হোয়াইটেনিং বডি লোশন
├─ সিক্রেট বডিপ্যাক
├─ PKG সিক্রেট লিপবাম
├─ PKG মাজুফল প্যাক
├─ PKG একনি জেল ক্রিম
├─ Tag Definition
├─ Push Sell Offer
├─ PKG Combo Details.
├─ Hairpack FAQ
├─ Melasma Remover pack FAQ
├─ Return Parcel Adjustment Guideline
├─ Closing Guideline NV
├─ LIP Bum FAQ
├─ All Portal Link
├─ Paikarighor Product Picture
├─ Non-Voice Order Cancel Guideline
├─ Up-Sell Call SOP
├─ Non-Voice SOP
├─ Voice FAQ
├─ Special Offer Campaign
└─ Order On Hold Reason Guidelines for Up-Sell Team
```

The site also has a **Search this site** box in the header.

## 3. Homepage layout (top to bottom)

1. **Header** — logo + "পাইকারিঘর", Home menu, search.
2. **Product categories** (4 drop-down groups):
   - **Hair** — সিক্রেট হেয়ার প্যাক · PKG রাইস ওয়াটার উইথ হার্বস শ্যাম্পু · PKG সিক্রেট হেয়ার অয়েল · সিক্রেট ড্যানড্রাফ প্যাক
   - **Face** — PKG সিক্রেট ফেসপ্যাক · PKG সিক্রেট একনিপ্যাক · PKG সিক্রেট পৌর মিনিমাইজার প্যাক · PKG সিক্রেট নাইট ক্রিম · PKG মেলাজমা রিমুভার প্যাক · মেলাসমা ক্রিম · PKG একনি জেল ক্রিম
   - **Body** — PKG হোয়াইটেনিং বডি লোশন · সিক্রেট বডিপ্যাক
   - **Lip & Maju** — PKG সিক্রেট লিপবাম · PKG মাজুফল প্যাক
3. **FAQ categories** (4 drop-down groups):
   - **Hair FAQ** — Hairpack FAQ
   - **Face FAQ** — Melasma Pack FAQ
   - **Body FAQ** — PKG হোয়াইটেনিং বডি লোশন · সিক্রেট বডিপ্যাক *(these link to the product pages, not separate FAQ pages)*
   - **Lip & Maju FAQ** — Lip Balm FAQ
4. **Resource buttons** (2 per row):
   - Up-Sell SOP Script · Non-Voice SOP
   - PKG Product Details *(Google Doc)* · Up-Sell Hold & Cancel Guideline's
   - All Portal Link and Tools · Paikarighor Product Picture
   - Objection Handling Top Queries | UP-Sell · Return Parcel Adjustment Guideline
   - Non-Voice Order Cancel Guideline · Non-Voice Order Cancel Guideline *(same button twice)*
   - Paikarighor Delivery Charge *(Google Doc)* · Our Official Website Link *(paikarighor.com)*
5. **Special Offer Campaign** button (highlighted band).
6. **Contact & payment numbers**:
   - Bkash/ Nagad Payment Number: 01722866438
   - Rocket Payment Number: 017228664383
   - Outbound Helpline Number: 09643214945
   - Inbound Hotline Number: 09643200900

## 4. Page inventory

| # | Page | Type | Where it appears on homepage | Images | Saved file |
|---|---|---|---|---|---|
| 00 | সিক্রেট হেয়ার প্যাক | Product | Hair | 0 | `pages/00-সকরট-হযর-পযক.md` |
| 01 | PKG রাইস ওয়াটার উইথ হার্বস শ্যাম্পু | Product | Hair | 0 | `pages/01-pkg-রইস-ওযটর-উইথ-হরবস-শযমপ.md` |
| 02 | PKG সিক্রেট হেয়ার অয়েল | Product | Hair | 0 | `pages/02-pkg-সকরট-হযর-অযল.md` |
| 03 | সিক্রেট ড্যানড্রাফ প্যাক | Product | Hair | 0 | `pages/03-সকরট-ডযনডরফ-পযক.md` |
| 04 | PKG সিক্রেট ফেসপ্যাক | Product | Face | 0 | `pages/04-pkg-সকরট-ফসপযক.md` |
| 05 | PKG সিক্রেট একনিপ্যাক | Product | Face | 0 | `pages/05-pkg-সকরট-একনপযক.md` |
| 06 | PKG সিক্রেট পৌর মিনিমাইজার প্যাক | Product | Face | 0 | `pages/06-pkg-সকরট-পর-মনমইজর-পযক.md` |
| 07 | PKG সিক্রেট নাইট ক্রিম | Product | Face | 0 | `pages/07-pkg-সকরট-নইট-করম.md` |
| 08 | PKG মেলাজমা রিমুভার প্যাক | Product | Face | 0 | `pages/08-pkg-মলজম-রমভর-পযক.md` |
| 09 | মেলাসমা ক্রিম | Product | Face | 0 | `pages/09-মলসম-করম.md` |
| 10 | PKG হোয়াইটেনিং বডি লোশন | Product | Body + Body FAQ | 0 | `pages/10-pkg-হযইটন-বড-লশন.md` |
| 11 | সিক্রেট বডিপ্যাক | Product | Body + Body FAQ | 0 | `pages/11-সকরট-বডপযক.md` |
| 12 | PKG সিক্রেট লিপবাম | Product | Lip & Maju | 0 | `pages/12-pkg-সকরট-লপবম.md` |
| 13 | PKG মাজুফল প্যাক | Product | Lip & Maju | 0 | `pages/13-pkg-মজফল-পযক.md` |
| 14 | PKG একনি জেল ক্রিম | Product | Face | 0 | `pages/14-pkg-একন-জল-করম.md` |
| 15 | Tag Definition | Guideline / Reference | **Menu only** (not linked on homepage) | 0 | `pages/15-tag-definition.md` |
| 16 | Push Sell Offer | Offer | **Menu only** (not linked on homepage) | 0 | `pages/16-push-sell-offer.md` |
| 17 | PKG Combo Details. | Offer / Combo info | **Menu only** (not linked on homepage) | 0 | `pages/17-pkg-combo-details.md` |
| 18 | Hairpack FAQ | FAQ | Hair FAQ (as "Hairpack FAQ") | 2 | `pages/18-hairpack-faq.md` |
| 19 | Melasma Remover pack FAQ | FAQ | Face FAQ (as "Melasma Pack FAQ") | 0 | `pages/19-melasma-remover-pack-faq.md` |
| 20 | Return Parcel Adjustment Guideline | Guideline | Button "Return Parcel Adjustment Guideline" | 0 | `pages/20-return-parcel-adjustment-guideline.md` |
| 21 | Closing Guideline NV | Guideline (Non-Voice) | **Menu only** (not linked on homepage) | 0 | `pages/21-closing-guideline-nv.md` |
| 22 | LIP Bum FAQ | FAQ | Lip & Maju FAQ (as "Lip Balm FAQ") | 1 | `pages/22-lip-bum-faq.md` |
| 23 | All Portal Link | Resources / Tools | Button "All Portal Link and Tools" | 0 | `pages/23-all-portal-link.md` |
| 24 | Paikarighor Product Picture | Image gallery | Button "Paikarighor Product Picture" | 15 | `pages/24-paikarighor-product-picture.md` |
| 25 | Non-Voice Order Cancel Guideline | Guideline (Non-Voice) | Button "Non-Voice Order Cancel Guideline" (appears twice) | 0 | `pages/25-non-voice-order-cancel-guideline.md` |
| 26 | Up-Sell Call SOP | SOP | Button "Up-Sell SOP Script" | 0 | `pages/26-up-sell-call-sop.md` |
| 27 | Non-Voice SOP | SOP | Button "Non-Voice SOP" | 0 | `pages/27-non-voice-sop.md` |
| 28 | Voice FAQ | FAQ (Objection handling) | Button "Objection Handling Top Queries \| UP-Sell" | 0 | `pages/28-voice-faq.md` |
| 29 | Special Offer Campaign | Offer | Button "Special Offer Campaign" | 0 | `pages/29-special-offer-campaign.md` |
| 30 | Order On Hold Reason Guidelines for Up-Sell Team | Guideline (Up-Sell) | Button "Up-Sell Hold & Cancel Guideline's" | 0 | `pages/30-order-on-hold-reason-guidelines-for-up-sell-team.md` |

### Product page format (all 15 product pages)
Each product page has a title banner, then a 6-column table:
**Product Name · কার জন্য উপযুক্ত? · মূল উপকারিতা · দাম + পরিমাণ · ব্যবহারবিধি · উপকরণ**,
followed (on some pages) by ingredient blocks with a heading and bullet list (e.g. আমলকি, হরিতকি, বহেরা, তিসি).
Product pages do **not** contain product photos; photos are only on "Paikarighor Product Picture" and two FAQ pages.

### FAQ / SOP colour coding (must be kept)
FAQ and SOP pages use coloured bold text to mark roles — e.g. **red** = customer question ("কাষ্টমারঃ …"), **green** = stage note ("প্রোডাক্ট এর ছবি শেয়ার করার পর।"), **blue** = agent prompt. These colours are recorded in `site-content.json` so their meaning can be kept in the new design.

## 5. Images

| File | Page | Shows |
|---|---|---|
| site-logo.png | Header (all pages) | Paikarighor logo |
| 18-01.png, 18-02.png | Hairpack FAQ | Secret Hair Pack pouch photos |
| 22-01.png | LIP Bum FAQ | Lip balm photo |
| 24-01.jpg | Product Picture | সিক্রেট হেয়ার প্যাক |
| 24-02.jpg | Product Picture | সিক্রেট ফেইস প্যাক |
| 24-03.jpg | Product Picture | সিক্রেট একনি প্যাক |
| 24-04.jpg | Product Picture | সিক্রেট ডেন্ড্রাফ প্যাক |
| 24-05.png | Product Picture | সিক্রেট পোর মিনিমাইজার প্যাক |
| 24-06.jpg | Product Picture | একনি জেল ক্রিম |
| 24-07.jpg | Product Picture | মেলাজমা রিমুভার প্যাক |
| 24-08.jpg | Product Picture | মেলাজমা ক্রিম |
| 24-09.jpg | Product Picture | সিক্রেট লিপবাম |
| 24-10.jpg | Product Picture | সিক্রেট বডি প্যাক |
| 24-11.jpg | Product Picture | মাজুফল |
| 24-12.jpg | Product Picture | নাইট ক্রিম |
| 24-13.jpg | Product Picture | PKG বডি লোশন |
| 24-14.jpg | Product Picture | সিক্রেট হেয়ার অয়েল |
| 24-15.jpg | Product Picture | রাইস ওয়াটার উইথ হার্বস শ্যাম্পু (caption is a link to the shampoo page) |

Background pictures behind page banners and sections are decorative theme images and were not collected (the new design replaces them).

## 6. External links and documents

| Link text | Found on | Destination | Status |
|---|---|---|---|
| PKG Product Details | Homepage | Google Doc `1Hn7RfxXzM…` | Public — text saved (`linked-documents/PKG-Product-Details.txt`). Covers 6 products; the doc uses tabs, so some tabs may not be in the copy |
| Paikarighor Delivery Charge | Homepage | Google Doc `1I1Jzj1Zpv…` | Public — text saved |
| Our Official Website Link | Homepage | https://paikarighor.com/ | Public |
| NUPORT | All Portal Link | https://app.nuport.io/ | Login page only (staff account needed) |
| Idesk | All Portal Link | https://agent.idesk360.com/ | Login page only (staff account needed) |
| Pendulum | All Portal Link | http://202.51.191.180/dialer/agent/index.php | **Could not be reached** (office/internal network) |
| Problem Form | All Portal Link | https://forms.gle/BzrpAnXpSEHmufqM9 | Opens, but the form is **closed** (not accepting responses) |
| Non-Voice Sales Dashboard | All Portal Link | Google Sheet `1e4WAUcr…` | Publicly viewable |
| Non-Voice Service Template | All Portal Link | Google Doc `1S3ga7JJ…` | Public — text saved |
| Up-Sell Report Dashboard | All Portal Link | Google Sheet `1Ym67jQz…` | Publicly viewable |
| Agent ID Card Apply Form | All Portal Link | Google Form `1Ni9e6F9…` | **Needs Google sign-in** — could not open |
| Cancel Form | All Portal Link | Google Form `1FAIpQLSek…` | Public, open |
| Website links inside text | Closing Guideline NV | www.paikarighor.com, …/product-category/haircare/, …/product-category/facepack/ | Plain text, not clickable on original |

The two dashboards' data was **not** copied — only their links are kept.

## 7. Could not be accessed
- Pendulum dialer (internal address).
- Agent ID Card Apply Form (requires sign-in).
- Problem Form (closed by owner).
- NUPORT and iDesk contents behind login (only the login pages are public; that is expected).
- Possibly some tabs of the "PKG Product Details" Google Doc.

## 8. Things that need your decision or input
1. **Rocket number** shows 12 digits: `017228664383` (Bkash/Nagad is `01722866438`). Keep as is, or correct?
2. **Duplicate button** "Non-Voice Order Cancel Guideline" appears twice on the homepage. Keep both, or show once?
3. **Body FAQ** links to the two body product pages (no separate FAQ pages exist). Keep the same?
4. **Menu-only pages** — Tag Definition, Push Sell Offer, PKG Combo Details., Closing Guideline NV are in the menu but not on the homepage. Add them to the homepage, or menu only?
5. **Different names for the same page** — e.g. menu "LIP Bum FAQ" vs homepage "Lip Balm FAQ"; "Melasma Remover pack FAQ" vs "Melasma Pack FAQ"; "Order On Hold Reason Guidelines for Up-Sell Team" vs "Up-Sell Hold & Cancel Guideline's"; "Voice FAQ" vs "Objection Handling Top Queries | UP-Sell". Keep both labels exactly as now?
6. **Google Docs** (PKG Product Details, Delivery Charge) — keep as links to Google Docs (always up to date), or copy their text into the new site?
7. **Public dashboards** — two Google Sheets anyone with the link can view. Please confirm that is intended.
8. **Price differences between pages** (left unchanged, for your review): e.g. Push Sell Offer lists "বডি প্যাক + বডি লোশন (২০০০ + ৪৫০ = ২৪৫০ টাকা)", while the product pages list Body Pack ৪৫০ টাকা and Body Lotion regular ২,০০০ / offer ৮৫০ টাকা.
9. **Access** — the original is open to anyone with the link. Should the new site stay open, or need a staff login?
10. **Search** — the original has "Search this site". Should the new site have search too?
